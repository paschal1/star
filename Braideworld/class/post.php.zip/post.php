<?php  
	class Post
	{
		private $conn;
		private $user_obj;

		public function __construct($conn, $user)
		{
			$this->conn = $conn;
			$this->user_obj = new User($conn, $user);
		}

		public function addNews($title, $content, $category, $status, $type, $tags, $image)
		{
			if(!empty($title) && !empty($content)) 
			{
				$time = time();
				$date = (date("F d, Y h:i A",  $time));
				$title = ucfirst($title);
				$title = mysqli_real_escape_string($this->conn, $title);
				$content = nl2br($content);
				$content = mysqli_real_escape_string($this->conn, $content);
				$added_by = $this->user_obj->getUserName();
				$sql = mysqli_query($this->conn, "SELECT id FROM category WHERE cat_title='$category'");
				$row = mysqli_fetch_array($sql);
				$cat_id = $row['id'];
				// $date = date("Y-m-d H:i:s");
				$query = mysqli_query($this->conn, "INSERT INTO news VALUES('','$title','$content','$added_by','$category','$cat_id','$image','$date','$tags','$status','$type','0','0','0',NOW());");
			}
		}

	 	 public function getbreakingnews(){
	 	 	$query = mysqli_query($this-> conn, "SELECT * FROM news WHERE type = 'breaking news' ORDER BY id DESC LIMIT 1");
	 	 	$str = "";
	 	 	while ($row = mysqli_fetch_array($query)) {
				  $post_cat_id = $row['post_cat_id'];
	 	 		$id = $row['id'];
	 	 		$title = $row['title'];
	 	 		$content = $row['content'];
	 	 		if(strlen($content) > 50) {
	 	 		$content = substr($content, 0, 100) . "...";
	 	 		}
				//   $time = time();
				// $date = (date("F d, Y h:i A",  $time));
	 	 		$cat_title = $row['post_category'];
				  $category = $row['post_category'];
	 	 		$cat_id = $row['post_cat_id'];
				  $image = $row['post_image'];
				  $added_by = $row['added_by'];
				  $date_added = $row['date_added'];
	 	 		$num_likes = $row['num_likes'];
			   $num_comments = $row['num_comments'];
			  $date_time_now = date("Y-m-d H:i:s");
				   $startCount = new DateTime($date_added);
			   $endCount = new DateTime($date_time_now);
			   $interval = $startCount->diff($endCount);
			   if($interval->h < 10 && $interval->d < 1 ) {
					$rand = rand(5,5);
	 			$str .= "<div class='post featured-post-lg mt-3'> 
    <div class='details clearfix '>
       
	<a href='singlepost.php?post_id=$id&cat_r=$category' class='category-badge'>$cat_title</a> &nbsp; 
	<li class='list-inline-item'>
	
		</li>
	<h2 class='post-title text-dark'>
		<a href='singlepost.php?post_id=$id&cat_r=$category' class='fw-bold'>BREAKING:&nbsp;&nbsp;$title</a>

		<ul class='meta list-inline mt-2 mb-0'>
		<li class='list-inline-item'>
			<a href='#' class='text-white small mt-0 mb-0'> <span>$added_by</span></a>
		</li>
		<li class='list-inline-item'>
			<a href='#' class='text-white small'> <span>$date_added</span></a>
		</li>
		
	</ul>
	</h2>
   
	
</div>
<a href='singlepost.php?post_id=$id&cat_r=$category'>
	<div class='thumb '>
		<div class='inner breaking'>
		<img src='admin/$image' alt='' class=' img-responive img-fluid w-100 rounded-0'>
		</div>
	</div>
</a>
</div>";
				
	 	  }
		//    elseif($interval->d != 1 && $interval-> h != 10){

		//   }
	 	}
 echo $str;
		  }
	

		  public function getfeaturednews()
		  {
			  $query = mysqli_query($this->conn, "SELECT * FROM news ORDER BY RAND() LIMIT 5");
			  $str = "";
			  while ($row = mysqli_fetch_array($query)) {
				  $post_cat_id = $row['post_cat_id'];
				  $image = $row['post_image'];
				  $content = substr($row['content'],0,72)."...";
				//   $time = time();
				//   $date = (date("F d, Y h:i A",  $time));
				  $date_added = $row['date_added'];
				  $cat_title = $row['post_category'];
				  $category = $row['post_category'];
				  $id = $row['id'];
				  $title = $row['title'];
				  $post_category = $row['post_category'];
				  $str .= "<div class='tab-pane fade show active d-flex ml-5' id='popular' aria-labelledby='popular-tab'
				  role='tabpanel'>
				  <!-- post  -->
				  <div class='post post-list-sm mb-4'>
					  <div class='thumb d-inline'>
						  <a href='singlepost.php?post_id=$id&cat_r=$category'>
							  <div class='inner'>
								<center>
								<img src='admin/$image' alt='' height='200px' width='190px' class='img-fluid ml-5 img-responsive' style='max-width:100px; max-height:60px;position:center;object-fit:cover;justify-content:center; object-position: -10% 4%; -50%;padding:0px;margin-right:30px;'>
								</center>
							  </div>
						  </a>
					  </div>
					
					  <div class='details clearfix ml-5 float-left mb-2 d-inline' style='left:-50px;' >
					 	<div class='spacer ml-5 d-flex'></div>
						  <h6 class='post-title my-0 '>
							  <a href='singlepost.php?post_id=$id&cat_r=$category' class='fs-6 fw-bold mb-1 text-dark '><small>$title</small></a> <br>
							<small class=' spacer text-center  text-secondary fw-normal float-right' style='position:absolute; right:25px;'>$date_added</small>
						</h6>
					  </div>
				  </div>
				   </div>
				 
			  ";
			  }
			  echo $str;
		  }
		  public function getfeatured()
		  {
			  $query = mysqli_query($this->conn, "SELECT * FROM news ORDER BY RAND() LIMIT 3");
			  $str = "";
			  while ($row = mysqli_fetch_array($query)) {
				  $post_cat_id = $row['post_cat_id'];
				  $time = time();
				  $date = (date("F d, Y h:i A",  $time));
				  $image = $row['post_image'];
				  $content = substr($row['content'],0,70)."...";
				  $date = $row['date_added'];
				  $cat_title = $row['post_category'];
				  	$category = $row['post_category'];
				  $id = $row['id'];
				  $post_category = $row['post_category'];
				  $str .= " <div class='post  mt-4 mb-5 mx-auto'>
				  <div class='thumb '>
					   
					  <a href='singlepost.php?post_id=$id&cat_r=$category'>
						  <div class='inner casual'>
							  <img src='admin/$image' alt='' class='img-responsive mx-auto  img-fluid'; style='max-width:auto; max-height:auto;object-position: 5px 10%; object-fit:cover;'>
						  </div>
					  </a>
				  </div>
					
					
				  <small> <a href='category.php?c_id=$post_cat_id' class='category-badge rounded-0 bg-dark mt-3'>$category</a></small>
				  <h6 class='post-title mb-2 mt-3 fs-6 fw-100'>
					  <a href='singlepost.php?post_id=$id' class='text-dark'>$content</a>
				  </h6>
				  <ul class='meta list-inline'>
						 
					  </ul>
			  </div> 
		  </div>";
			  }
			  echo $str;
		  }
		 
	   public function gettopstories(){
		
	 	$query = mysqli_query($this->conn, "SELECT * FROM news WHERE type='Casual news' ORDER BY id DESC LIMIT 9");
	 	$str = "";
	 	while ($row = mysqli_fetch_array($query)) {
			 $post_cat_id = $row['post_cat_id'];
	 		$id = $row['id'];
	 		$content = $row['content'];
	 		if (strlen($content) > 50) {
	 		$content = substr($content, 0, 70) . "...";
	 		}
			 $time = time();
			 $date = (date("F d, Y h:i A"));
	 		$date = $row['date_added'];
			$title = $row['title'];
	 		$added_by = $row['added_by'];
	 		$category = $row['post_category'];
	 		$image = $row['post_image'];
	 		$num_likes = $row['num_likes'];
	 		$num_comments = $row['num_comments'];
	 		$post_category = $row['post_category'];

	 		$str .= "<div class='col-sm-6 col-md-6 col-lg-4 mt-4 mb-2'>
                      
	 		<div class='post  mt-2 mx-auto'>
	 			<div class='thumb '>
					  
	 				<a href='singlepost.php?post_id=$id'>
	 					<div class='inner casual'>
	 						<img src='admin/$image' alt='' class='img-responsive mx-auto  img-fluid'; style='max-width:auto; max-height:auto;object-position: 5px 10%'>
	 					</div>
	 				</a>
	 			</div>
				   
				   
	 			<small> <a href='category.php?c_id=$post_cat_id' class='category-badge mt-3'>$category</a></small>
	 			<h6 class='post-title   fs-6 fw-100'>
	 				<a href='singlepost.php?post_id=$id ' class='text-dark fw-bold'>$title</a>
					 <ul class='meta list-inline mt-2 mb-0'>
					 <li class='list-inline-item'>
						 <a href='#' class='text-dark small fw-bold mt-0 mb-0'> <span>$added_by</span></a>
					 </li>
					 <li class='list-inline-item'>
						 <a href='#' class='text-secondary small'> <span><small>$date</small></span></a>
					 </li>
					 
				 </ul>
	 			</h6>
	 			
	 		</div> 
	 	</div>";
	 	}
	 	echo $str;
	 }


	 public function getPostBySearch($keyword)
	 {
		
		
		 $query = mysqli_query($this->conn, "SELECT * FROM news WHERE content LIKE '%$keyword%' ORDER BY id DESC LIMIT 24");
		 $str = "";
	 if(mysqli_num_rows($query) === 0) {
		 $str = "<h1 class='text-center text-danger mt-5'>No results found!</h1>";
	 }	
	 else {
		 while ($row = mysqli_fetch_array($query)) {
			 $post_cat_id = $row['post_cat_id'];
			 $id = $row['id'];
			 $content = $row['content'];
			 if (strlen($content) > 200) {
				 $content = substr($content, 0, 100) . "...";
			 }
			//  $time = time();
			//  $date = (date("F d, Y h:i A"));
			 $category = $row['post_category'];
			 $added_by = $row['added_by'];
			 $date = $row['date_added'];
			 $image = $row['post_image'];
			 $num_likes = $row['num_likes'];
			 $num_comments = $row['num_comments'];
			 $str .= "<div class='col-sm-6 col-md-6 col-lg-4 mb-1'>
                      
	 		<div class='post mt-2 mx-auto ' style = 'margin-bottom:2px;'>
	 			<div class='thumb '>
					  
	 				<a href='singlepost.php?post_id=$id&cat_r=$category'>
	 					<div class='inner casual'>
	 						<img src='admin/$image' alt='' class='img-responsive   img-fluid'; style='max-width:auto; max-height:auto;object-position: 5px 10%'>
	 					</div>
	 				</a>
	 			</div>
				   
				   
	 			<small> <a href='category.php?c_id=$post_cat_id' class='category-badge mt-3'>$category</a></small>
	 			<h6 class='post-title mb-2 mt-3'>
	 				<a href='singlepost.php?post_id=$id&cat_r=$category'class='text-danger'>$content</a>
					 <ul class='meta list-inline mb-0 mt-1'>
	 					<li class='list-inline-item'>
						 <a href='#' class='text-dark fw-bold small'> <span>$added_by</span></a>
	 					</li>
						
	 					 <li class='list-inline-item fw-normal  small'>$date &nbsp; <a href='' style='color:#9faabb;'><i class='fas fa-thumbs-up fw-normal small text-dark'><span> &nbsp;$num_likes</span></i></a> &nbsp; <a href='' style='color:#9faabb;'><i class='fas fa-comment small text-dark fw-normal'><span> &nbsp;$num_comments</span></i></a></li>
	 				</ul>
	 			</h6>
	 			
	 		</div> 
	 	</div>";
		 }
	 }
		 echo $str;
	 }
	 public function getFullNews($id)
		{
			$query = mysqli_query($this->conn, "SELECT * FROM news WHERE id=$id");
			$str = "";
			$time = time();
			// $date = (date("F d, Y h:i A"));
			$row = mysqli_fetch_array($query);
			$id = $row['id'];
			$title = $row['title'];
			$content = $row['content'];
			$added_by = $row['added_by'];
			$post_category = $row['post_category'];
			$post_cat_id = $row['post_cat_id'];
			$image = $row['post_image'];
			$tags = explode(',', $row['tags']);
			$date = $row['date_added'];
			$views = $row['num_views'];
			$comments = $row['num_comments'];
			$num_likes = $row['num_likes'];
			$str_tags = "";
			foreach ($tags as $tag) {
				// $str_tags .= "<a href='tags.php?tag=$tag' class='btn btn-danger small rounded-0 '>$tag</a>";
				$str_tags .= "<a href='tags.php?tag=$tag' class='btn btn-danger small rounded-0 '>$tag</a>" . " ";
			}

			$str .= "<div class='details clearfix '>
       
	
			</div>
				<a href='singlepost.php?post_id=$id&cat_r=$post_category'>
			<div class='thumb '>
			<div class='inner breaking'>
			
				<img src='admin/$image' alt='' class=' img-responive img-fluid w-100' style=';object-position: 5px 10%;'>
			</a>
			</div>
			 </div>
			<a href='category.php?c_id=$post_cat_id' class='category-badge rounded-0 bg-danger mt-4'>$post_category</a> &nbsp; 
			<h5 class='fw-bold fs-3 text-dark text-capitalize'>$title</h5>
			
		
			</div>
			<!-- =============================================== -->
			<div class='single-post mt-3'>
			<div class='single-post-cat post'>
			
				<ul class='meta list-inline mb-3 '>
				 <li class='list-inline-item'>
					 <span>Posted By:</span>&nbsp;&nbsp;<span class='text-danger fw-bold text-dark'>$added_by</span>
				 </li>
					 <li class='list-inline-item  text-secondary'><small>$date </small>&nbsp;<a href='' style='color:#9faabb;'><i class='fas fa-eye fw-normal text-dark'><span> &nbsp;$views</span></i></a> &nbsp; <a href='singlepost.php?post_id=$id&cat_r=$post_category&like_id=$id' style='color:#9faabb;'><i class='fas fa-thumbs-up text-dark fw-normal'><span> &nbsp;$num_likes</span></i></a> &nbsp; <a href='' style='color:#9faabb;'><i class='fas fa-comment text-dark fw-normal'><span> &nbsp;$comments</span></i></a></li>
					 
					 </ul>
					 <ul class=' text-white list-unstyled list-inline mb-0 mx-auto mr-5'>
    <li class='list-inline-item mr-3'>
    <a style='color: #3b5998;' href='#!' role='button'
    ><i class='fab fa-facebook-f fa-lg'></i
    ></a>

    </li>
   <li class='list-inline-item mr-3'>
        <!-- Twitter -->
    <a style='color: #55acee;' href='#!' role='button'
    ><i class='fab fa-twitter fa-lg'></i
    ></a>
   </li>

    

   <li class='list-inline-item mr-3'>
        <!-- Instagram -->
    <a style='color: #ac2bac;' href='#!' role='button'
    ><i class='fab fa-instagram fa-lg'></i
    ></a>
   </li>

   <li class='list-inline-item mr-3'>
        <!-- Instagram -->
    <a style='color: #25d366;' href='#!' role='button'
    ><i class='fab fa-whatsapp fa-lg'></i
    ></a>
   </li>

</ul>
					</div>
					<div class='single-post-cnt mt-4 '>
			 
				   <p class='text-justify text-dark fs-5 mx-auto' style='word-spacing:-2px;'>
				   	$content
				   </p>
			  
			</div>
		
			<div class='widget '>
				<div class='widget-header '>
					<h3 class='widget-title'>Tags </h3>
				</div>
				<div class='widget-content'>
					<a href='tags.php?tag=$tag' class=''>$str_tags</a> <br>
					
				</div>
				
			</div>";

                        return $str;
		}
		public function getmostreadnews() 
		{
			$query = mysqli_query($this->conn, "SELECT * FROM news WHERE timestamped>DATE_SUB(curdate(),INTERVAL 1 WEEK) ORDER BY num_views DESC LIMIT 8");
			$str = "";
			while ($row = mysqli_fetch_array($query)) {
				$post_cat_id = $row['post_cat_id'];
				$id = $row['id'];
				$content = $row['content'];
				$date = $row['date_added'];
				$title = $row['title'];
				if (strlen($content) > 200) {
					$content = substr($content, 0, 100) . "...";
				}
				// $time = time();
				// $date = (date("F d, Y h:i A"));
				$added_by = $row['added_by'];
				$category = $row['post_category'];
				$image = $row['post_image'];
				$num_likes = $row['num_likes'];
				$post_cat_id = $row['post_cat_id'];
				$num_comments = $row['num_comments'];

				$str .= "<div class='col-sm-6'>
				<!-- post  -->
				<div class='post'>
					<div class='thumb '>
						<a href='category.php?c_id=$post_cat_id' class='category-badge position-absolute'>$category</a>
					   
						<a href='singlepost.php?post_id=$id&cat_r=$category'>
							<div class='inner'>
								<img src='admin/$image' alt='' class='img-responsive img-fluid' style='width:600px; height:250px;object-position: 5px 10%;object-fit:cover;'>
							</div>
						</a>
					</div>
					
					<h6 class='post-title mb-2 mt-3 fs-6 text-dark'>
						<a href='singlepost.php?post_id=$id&cat_r=$category' class='text-dark fw-bold'>$title</a>
					</h6>
					<p class='excerpt mb-0 text-dark  small'>
						$content
					</p>
					<ul class='meta list-inline mt-1  mb-0'>
						<li class='list-inline-item small fw-bold text-dark'><small>$added_by</small></li>
						<li class='list-inline-item small  text-secondary'><small>$date</small></li>
					</ul>
				</div>
			</div>";
			}
			echo $str;
    }

	public function getNewsbytags($tags)
	 {
		 $query = mysqli_query($this->conn, "SELECT * FROM news WHERE tags LIKE '%$tags%' ORDER BY id DESC LIMIT 24");
		 $str = "";
	 if(mysqli_num_rows($query) === 0) {
		 $str = "<h1 class='text-center text-danger mt-5'>No results found!</h1>";
	 }	
	 else {
		 while ($row = mysqli_fetch_array($query)) {
			 $post_cat_id = $row['post_cat_id'];
			 $id = $row['id'];
			 $content = $row['content'];
			 if (strlen($content) > 200) {
				 $content = substr($content, 0, 100) . "...";
			 }
			 $time = time();
			//  $date = (date("F d, Y h:i A"));
			 $category = $row['post_category'];
			 $added_by = $row['added_by'];
			 $date = $row['date_added'];
			 $image = $row['post_image'];
			 $num_likes = $row['num_likes'];
			 $num_comments = $row['num_comments'];

			 $str .= "<div class='col-sm-6 col-md-6 col-lg-4 mb-1'>
                      
	 		<div class='post mt-2 mx-auto ' style = 'margin-bottom:2px;'>
	 			<div class='thumb '>
					  
	 				<a href='singlepost.php?post_id=$id&cat_r=$category'>
	 					<div class='inner casual'>
	 						<img src='admin/$image' alt='' class='img-responsive   img-fluid'; style='max-width:auto; max-height:auto;object-position: 5px 10%'>
	 					</div>
	 				</a>
	 			</div>
				   
				   
	 			<small> <a href='category.php?c_id=$post_cat_id' class='category-badge mt-3'>$category</a></small>
	 			<h6 class='post-title mb-2 mt-3'>
	 				<a href='singlepost.php?post_id=$id&cat_r=$category'>$content</a>
	 			</h6>
	 			<ul class='meta list-inline mb-0'>
	 					<li class='list-inline-item'>
						 <a href='#' class='fw-bold text-dark small'><span>$added_by</span></a>
	 					</li>
						
	 					<!---- <li class='list-inline-item'>$date &nbsp; <a href='' style='color:#9faabb;'><i class='fas fa-thumbs-up '><span> &nbsp;$num_likes</span></i></a> &nbsp; <a href='' style='color:#9faabb;'><i class='fas fa-comment'><span> &nbsp;$num_comments</span></i></a></li>--->
	 				</ul>
	 		</div> 
	 	</div>";
		 }
	 }
		 echo $str;
}
	public function getpopulartags($tags)
	 {
		 $query = mysqli_query($this->conn, "SELECT * FROM news WHERE tags LIKE '%$tags%' ORDER BY id DESC LIMIT 24");
		 $str = "";
	 if(mysqli_num_rows($query) === 0) {
		 $str = "<h1 class='text-center text-danger mt-5'>No results found!</h1>";
	 }	
	 else {
		 while ($row = mysqli_fetch_array($query)) {
			 $post_cat_id = $row['post_cat_id'];
			 $id = $row['id'];
			 $content = $row['content'];
			 if (strlen($content) > 200) {
				 $content = substr($content, 0, 100) . "...";
			 }
			//  $time = time();
			//  $date = (date("F d, Y h:i A"));
			 $category = $row['post_category'];
			 $added_by = $row['added_by'];
			 $date = $row['date_added'];
			 $image = $row['post_image'];
			 $num_likes = $row['num_likes'];
			 $num_comments = $row['num_comments'];

			 $str .= "<div class='col-sm-6 col-md-6 col-lg-4 mb-1'>
                      
	 		<div class='post mt-2 mx-auto ' style = 'margin-bottom:2px;'>
	 			<div class='thumb '>
					  
	 				<a href='singlepost.php?post_id=$id&cat_r=$category'>
	 					<div class='inner casual'>
	 						<img src='admin/$image' alt='' class='img-responsive   img-fluid'; style='max-width:auto; max-height:auto;object-position: 5px 10%'>
	 					</div>
	 				</a>
	 			</div>
				   
				   
	 			<small> <a href='category.php?c_id=$post_cat_id' class='category-badge mt-3'>$category</a></small>
	 			<h6 class='post-title mb-2 mt-3'>
	 				<a href='singlepost.php?post_id=$id&cat_r=$category'>$content</a>
	 			</h6>
	 			<ul class='meta list-inline mb-0'>
	 					<li class='list-inline-item'>
						 <a href='#'><i>By</i>:<span>$added_by</span></a>
	 					</li>
						
	 					<!---- <li class='list-inline-item'>$date &nbsp; <a href='' style='color:#9faabb;'><i class='fas fa-thumbs-up '><span> &nbsp;$num_likes</span></i></a> &nbsp; <a href='' style='color:#9faabb;'><i class='fas fa-comment'><span> &nbsp;$num_comments</span></i></a></li>--->
	 				</ul>
	 		</div> 
	 	</div>";
		 }
	 }
		 echo $str;
}
public function getentertainmentnews(){
	$query = mysqli_query($this->conn, "SELECT * FROM news WHERE post_category = 'entertainment' ORDER BY id DESC LIMIT 8");
	$str = "";
	while($row = mysqli_fetch_array($query)){
		$content = substr($row['content'], 0, 30). "...";
		$image = $row['post_image'];
		$title = $row['title'];
		$id = $row['id'];
		// $time = time();
		// $date = (date("F d, Y h:i A"));
		$date = $row['date_added'];
		$added_by = $row['added_by'];
		$date = $row['date_added'];
		$category = $row['post_category'];
		$post_cat_id = $row['post_cat_id'];
		$str .= "<div class='col-sm-6'>
		<div class='post casual'>
			<div class='thumb '>
				<!---<a href='category.php?c_id=$post_cat_id' class='category-badge position-absolute'>$</a>--->
			   
				<a href='singlepost.php?post_id=$id&cat_r=$category'>
					<div class='inner'>
						<img src='admin/$image' alt='' style='width:600px; height:250px;object-position: 5px 10%;object-fit:cover;'>
					</div>
				</a>
			</div>
		
			<h6 class='post-title  mt-3 text-dark'>
				<a href='singlepost.php?post_id=$id&cat_r=$category' class='text-dark fw-bold'>$title</a>
				<ul class='meta list-inline mb-0 mt-1 fw-100' style='font-weight:normal;'>
				<li class='list-inline-item text-dark fw-bold small'><small>$added_by</small></li>
			<li class='list-inline-item text-secondary fw-100 small'><small> $date</small></li>
			</ul>
			</h6>
			
		</div>
		</div> ";
			}
			echo $str;
}
public function getlatestentertainmentnews(){
	$query = mysqli_query($this->conn, "SELECT * FROM news WHERE post_category = 'celebrity gossip' ORDER BY id DESC LIMIT 4");
	$str = "";
	while($row = mysqli_fetch_array($query)){
		$content = substr($row['content'], 0, 30). "...";
		$image = $row['post_image'];
		$title = $row['title'];
		$id = $row['id'];
		$time = time();
		// $date = (date("F d, Y h:i A"));
		$added_by = $row['added_by'];
		$date = $row['date_added'];
		$category = $row['post_category'];
		$post_cat_id = $row['post_cat_id'];
		$str .= " <div class='post post-over-content col-sm-3 mb-3 col-6 col-md-3'>
		<div class='details clearfix mt-5'>
			
			<h6 class='post-title mt-5'>
				<a href='#' class=' mt-5 fw-bold small fs-6' style='margin-bottom:-25px;'><small>$title   </small></a>
			</h6>
			<ul class='meta list-inline mb-0'>
				<li class='list-inline-item'>
					<a href='#' class='fw-bold small'>$added_by</a>
				</li>
				
			</ul>
		</div>
		<a href='singlepost.php?post_id=$id&cat_r=$category'>
			<div class='thumb'>
				<div class='inner'>
					<img src='admin/$image' alt='' class='img-responsive img-fluid' style='width:600px; height:220px;object-position: 5px 10%;object-fit:cover;'>
				</div>
			</div>
		</a>
	</div>";
			}
			echo $str;
}
public function getrecentNews() 
		{
			$query = mysqli_query($this->conn, "SELECT * FROM news WHERE timestamped>DATE_SUB(curdate(),INTERVAL 1 HOUR) ORDER BY num_views ASC LIMIT 4");
			$str = "";
			while ($row = mysqli_fetch_array($query)) {
				$post_cat_id = $row['post_cat_id'];
				$id = $row['id'];
				$content = $row['content'];
				$date = $row['date_added'];
				$title = $row['title'];
				if (strlen($content) > 200) {
					$content = substr($content, 0, 100) . "...";
				}
				// $time = time();
				// $date = (date("F d, Y h:i A"));
				$category = $row['post_category'];
				$image = $row['post_image'];
				$num_likes = $row['num_likes'];
				$post_cat_id = $row['post_cat_id'];
				$num_comments = $row['num_comments'];

				$str .= "<div class='col-md-12  col-sm-12'>
				<!-- post  -->
				<div class='post post-list clearfix'>
					<div class='thumb '>
					   
						<a href='singlepost.php?post_id=$id&cat_r=$category' >
							<div class='inner'>
								<img src='admin/$image' alt='' class='img-responsive img-fluid' style='width:600px; height:220px;object-position: 5px 10%;object-fit:cover;'>
							</div>
						</a>
					</div>
					<div class='details'>
						<ul class='meta list-inline mb-3'>
							<li class='list-inline-item'>
							   
							</li>
							<li class='list-inline-item'>
							<a href='category.php?c_id=$post_cat_id' class='category-badge   rounded-0 text-white'>$category</a>
							</li>
						<!----	<li class='list-inline-item' class=>$date</li> ---->
						</ul>
						<h6 class='post-tile text-danger'>
							<a href='singlepost.php?post_id=$id&cat_r=$category' class='text-danger fw-bold'>
								$title
							</a>
						</h6>
						<p class='excerpt mb-0'>
						<a href='singlepost.php?post_id=$id&cat_r=$category'>
						$content
						</a>
						</p>
						<div class='post-bottom clearfix d-flex align-items-center'>
							<div class='social-share me-auto'>
								<button class='toggle-button icon-share'></button>
								<ul class='icons list-unstyled list-inline mb-0'>
									<li class='list-inline-item'>
										<a href='#'><i class='fab fa-facebook-f'></i></a>
									</li>
									<li class='list-inline-item'>
										<a href='#'><i class='fab fa-twitter'></i></a>
									</li>
									<li class='list-inline-item'>
										<a href='#'><i class='fab fa-whatsapp'></i></a>
									</li>
								   
								</ul>
							</div>
							<div class='more-button float-end'>
								<a href='#'><span class='icon-options'></span></a>
							</div>
						</div>
					</div>
				</div>
			</div>";
			}
			echo $str;
		}
		public function getcelebritynews(){
			$query = mysqli_query($this->conn, "SELECT * FROM news WHERE post_category = 'celebrity gossip' ORDER BY id DESC LIMIT 6");
			$str = "";
			while($row = mysqli_fetch_array($query)){
				$content = substr($row['content'], 0, 30). "...";
				$image = $row['post_image'];
				$title = $row['title'];
				$id = $row['id'];
				$time = time();
				// $date = (date("F d, Y h:i A"));
				$date = $row['date_added'];
				$added_by = $row['added_by'];
				// $date = $row['date_added'];
				$category = $row['post_category'];
				$post_cat_id = $row['post_cat_id'];
				$str .= "
				<div class='post post-over-content col-md-6'>
					<div class='details clearfix'>
						<a href='category.php?c_id=$post_cat_id' class='category-badge'>$category</a>
						<h6 class='post-title'>
							<a href='#' class='fw-bold'>$title</a>
						</h6>
						<ul class='meta list-inline mb-0'>
							<li class='list-inline-item'>
								<a href='#' class='fw-bold text-white'>$added_by</a>
							</li>
							<li class='list-inline-item text-secondary small'><small> $date</small></li>
						</ul>
					</div>
					<a href='singlepost.php?post_id=$id&cat_r=$category'>
						<div class='thumb'>
							<div class='inner'>
								<img src='admin/$image' alt='' class='img-responsive img-fluid' style='width:600px; height:220px;object-position: 5px 10%;object-fit:cover;'>
							</div>
						</div>
					</a>
				</div>";
					}
					echo $str;
				}
		public function getviralnews(){
			$query = mysqli_query($this->conn, "SELECT * FROM news WHERE post_category = 'viral news' ORDER BY id DESC LIMIT 6");
			$str = "";
			while($row = mysqli_fetch_array($query)){
				$content = substr($row['content'], 0, 30). "...";
				$image = $row['post_image'];
				$title = $row['title'];
				$id = $row['id'];
				$time = time();
				// $date = (date("F d, Y h:i A"));
				$added_by = $row['added_by'];
				$date = $row['date_added'];
				$category = $row['post_category'];
				$post_cat_id = $row['post_cat_id'];
				$str .= "
			
				<div class='post post-over-content col-md-6'>
					<div class='details clearfix'>
						<a href='category.php?c_id=$post_cat_id' class='category-badge'>$category</a>
						<h6 class='post-title'>
							<a href='#' class='fw-bold'>$title</a>
						</h6>
						<ul class='meta list-inline mb-0'>
							<li class='list-inline-item'>
								<a href='#' class='fw-bold text-white small'>$added_by</a>
							</li>
							<li class='list-inline-item text-white small'><small> $date</small></li>
						</ul>
					</div>
					<a href='singlepost.php?post_id=$id&cat_r=$category'>
						<div class='thumb'>
							<div class='inner'>
								<img src='admin/$image' alt='' class='img-responsive img-fluid' style='width:600px; height:220px;object-position: 5px 10%;object-fit:cover;'>
							</div>
						</div>
					</a>
				</div>
				";
					}
					echo $str;
				}
		public function getsportnews(){
			$query = mysqli_query($this->conn, "SELECT * FROM news WHERE post_category = 'sports' ORDER BY id DESC LIMIT 6");
			$str = "";
			while($row = mysqli_fetch_array($query)){
				$content = substr($row['content'], 0, 30). "...";
				$image = $row['post_image'];
				$title = $row['title'];
				$id = $row['id'];
				$time = time();
				// $date = (date("F d, Y h:i A"));
				$added_by = $row['added_by'];
				$date = $row['date_added'];
				$category = $row['post_category'];
				$post_cat_id = $row['post_cat_id'];
				$str .= "
			
				<div class='post post-over-content col-md-6'>
					<div class='details clearfix'>
						<a href='category.php?c_id=$post_cat_id' class='category-badge'>$category</a>
						<h6 class='post-title'>
							<a href='#' class='fw-bold'>$title</a>
						</h6>
						<ul class='meta list-inline mb-0'>
							<li class='list-inline-item'>
								<a href='#' class='fw-bold text-white small'>$added_by</a>
							</li>
							<li class='list-inline-item text-white small'><small> $date</small></li>
						</ul>
					</div>
					<a href='singlepost.php?post_id=$id&cat_r=$category'>
						<div class='thumb'>
							<div class='inner'>
								<img src='admin/$image' alt='' class='img-responsive img-fluid' style='width:600px; height:220px;object-position: 5px 10%;object-fit:cover;'>
							</div>
						</div>
					</a>
				</div>
				";
					}
					echo $str;
				}

			public function getlatestNews() {
		
			$query = mysqli_query($this->conn, "SELECT * FROM news WHERE timestamped>DATE_SUB(curdate(),INTERVAL 1 WEEK) ORDER BY num_views ASC LIMIT 8");
			$str = "";
			while ($row = mysqli_fetch_array($query)) {
				$post_cat_id = $row['post_cat_id'];
				$id = $row['id'];
				$content = $row['content'];
				$date = $row['date_added'];
				$title = $row['title'];
				if (strlen($content) > 200) {
					$content = substr($content, 0, 100) . "...";
				}
				// $time = time();
				// $date = (date("F d, Y h:i A"));
				$category = $row['post_category'];
				$image = $row['post_image'];
				$num_likes = $row['num_likes'];
				$post_cat_id = $row['post_cat_id'];
				$num_comments = $row['num_comments'];

				$str .= "<div class='details clearfix text-justify text-wrap mb-4 '>
				<h4 class='post-title my-0 text-justify text-dark'>
					<a href='singlepost.php?post_id=$id&cat_r=$category' class='text-dark class='fw-bold'>$title</a>
				</h4>
				
			</div>";
			}
			echo $str;
		}
		public function gettopfortheweek() 
		{
			$query = mysqli_query($this->conn, "SELECT * FROM news WHERE timestamped>DATE_SUB(curdate(),INTERVAL 1 WEEK) ORDER BY num_views DESC LIMIT 6");
			$str = "";
			while ($row = mysqli_fetch_array($query)) {
				$post_cat_id = $row['post_cat_id'];
				$id = $row['id'];
				$content = $row['content'];
				$date = $row['date_added'];
				$title = $row['title'];
				if (strlen($content) > 200) {
					$content = substr($content, 0, 50) . "...";
				}
				// $time = time();
				// $date = (date("F d, Y h:i A"));
				$category = $row['post_category'];
				$image = $row['post_image'];
				$num_likes = $row['num_likes'];
				$post_cat_id = $row['post_cat_id'];
				$num_comments = $row['num_comments'];

				$str .= "<div class='insta-item col-sm-2 col-6 col-md-2'>
				<a href='#'>
					<img src='admin/$image' alt='' height='40px'>
				</a>
			</div>";
			}
			echo $str;
		}
		
}